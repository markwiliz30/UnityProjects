﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* A stat modifier. */

[System.Serializable]
public class StatModifier {

	public int modifier;

}
